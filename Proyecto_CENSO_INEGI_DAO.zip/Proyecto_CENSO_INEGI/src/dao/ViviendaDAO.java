package dao;

import modelo.Vivienda;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ViviendaDAO {

    // INSERT
    public boolean insertar(Vivienda v) {
        String sql = "INSERT INTO viviendas (calle, num_exterior, num_interior, colonia, codigo_postal, id_localidad, id_municipio, id_tipo_vivienda, num_cuartos, num_banios, material_predominante, servicios_basicos, observaciones, estatus) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConexionBD.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, v.getCalle());
            ps.setString(2, v.getNumExterior());
            ps.setString(3, v.getNumInterior());
            ps.setString(4, v.getColonia());
            ps.setString(5, v.getCodigoPostal());
            ps.setInt(6, v.getIdLocalidad());
            ps.setInt(7, v.getIdMunicipio());
            ps.setInt(8, v.getIdTipoVivienda());
            ps.setInt(9, v.getNumCuartos());
            ps.setInt(10, v.getNumBanios());
            ps.setString(11, v.getMaterialPredominante());
            ps.setString(12, v.getServiciosBasicos());
            ps.setString(13, v.getObservaciones());
            ps.setBoolean(14, v.isEstatus());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error insertar vivienda: " + e.getMessage());
            return false;
        }
    }

    // SELECT
    public List<Vivienda> listar() {
        List<Vivienda> lista = new ArrayList<>();
        String sql = "SELECT * FROM viviendas";

        try (Connection conn = ConexionBD.getConexion();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Vivienda v = new Vivienda();

                v.setIdVivienda(rs.getInt("id_vivienda"));
                v.setCalle(rs.getString("calle"));
                v.setNumExterior(rs.getString("num_exterior"));
                v.setNumInterior(rs.getString("num_interior"));
                v.setColonia(rs.getString("colonia"));
                v.setCodigoPostal(rs.getString("codigo_postal"));
                v.setIdLocalidad(rs.getInt("id_localidad"));
                v.setIdMunicipio(rs.getInt("id_municipio"));
                v.setIdTipoVivienda(rs.getInt("id_tipo_vivienda"));
                v.setNumCuartos(rs.getInt("num_cuartos"));
                v.setNumBanios(rs.getInt("num_banios"));
                v.setMaterialPredominante(rs.getString("material_predominante"));
                v.setServiciosBasicos(rs.getString("servicios_basicos"));
                v.setObservaciones(rs.getString("observaciones"));
                v.setEstatus(rs.getBoolean("estatus"));

                lista.add(v);
            }

        } catch (SQLException e) {
            System.out.println("Error listar viviendas: " + e.getMessage());
        }

        return lista;
    }

    // UPDATE
    public boolean actualizar(Vivienda v) {
        String sql = "UPDATE viviendas SET calle=?, num_exterior=?, num_interior=?, colonia=?, codigo_postal=?, id_localidad=?, id_municipio=?, id_tipo_vivienda=?, num_cuartos=?, num_banios=?, material_predominante=?, servicios_basicos=?, observaciones=? WHERE id_vivienda=?";

        try (Connection conn = ConexionBD.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, v.getCalle());
            ps.setString(2, v.getNumExterior());
            ps.setString(3, v.getNumInterior());
            ps.setString(4, v.getColonia());
            ps.setString(5, v.getCodigoPostal());
            ps.setInt(6, v.getIdLocalidad());
            ps.setInt(7, v.getIdMunicipio());
            ps.setInt(8, v.getIdTipoVivienda());
            ps.setInt(9, v.getNumCuartos());
            ps.setInt(10, v.getNumBanios());
            ps.setString(11, v.getMaterialPredominante());
            ps.setString(12, v.getServiciosBasicos());
            ps.setString(13, v.getObservaciones());
            ps.setInt(14, v.getIdVivienda());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error actualizar vivienda: " + e.getMessage());
            return false;
        }
    }

    // DELETE ( solo elimina de manera logica)
    public boolean eliminar(int id) {
        String sql = "UPDATE viviendas SET estatus = 0 WHERE id_vivienda = ?";

        try (Connection conn = ConexionBD.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error eliminar vivienda: " + e.getMessage());
            return false;
        }
    }
}